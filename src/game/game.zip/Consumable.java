package game;

public interface Consumable {
    void consume(Player player);
}
