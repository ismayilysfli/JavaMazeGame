package game;

public interface Activatable {
    void activate(Player player);
}
