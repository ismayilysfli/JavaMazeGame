package game;

public class AdventureGame {
    public static void main(String[] args) {
        new GameManager().startGame();
    }
}
