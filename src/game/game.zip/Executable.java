package game;

public interface Executable {
    void execute(Player player);
}
